const instancesList = document.querySelector('.instances-list');
const webviewContainer = document.querySelector('.webview-container');
const addInstanceBtn = document.getElementById('add-instance-btn');

let instanceCounter = 0;

function showInstance(instanceId) {
    document.querySelectorAll('.webview-content').forEach(view => view.style.display = 'none');
    document.querySelectorAll('.instance-button').forEach(btn => btn.classList.remove('active'));
    document.getElementById(instanceId).style.display = 'flex';
    document.querySelector(`[data-instance="${instanceId}"]`).classList.add('active');
}

// NOVA FUNÇÃO para buscar dados do perfil
async function updateProfileInfo(webview, button) {
    try {
        // Script que será executado DENTRO da página do WhatsApp
        const profileData = await webview.executeJavaScript(`
            (function() {
                const profile = {};
                const nameElement = document.querySelector('header [role="button"] span[title]');
                const imgElement = document.querySelector('header [role="button"] img');
                if (nameElement) profile.name = nameElement.innerText;
                if (imgElement) profile.imgUrl = imgElement.src;
                return profile;
            })();
        `);

        if (profileData && profileData.name) {
            // Limpa o botão e adiciona a foto e o nome
            button.innerHTML = ''; // Limpa o "WhatsApp X"
            
            const profileImg = document.createElement('img');
            profileImg.src = profileData.imgUrl;
            profileImg.style.width = '32px';
            profileImg.style.height = '32px';
            profileImg.style.borderRadius = '50%';

            const profileName = document.createElement('span');
            profileName.textContent = profileData.name;

            button.appendChild(profileImg);
            button.appendChild(profileName);
        }
    } catch (error) {
        console.error('Erro ao buscar dados do perfil:', error);
    }
}

function addInstance() {
    instanceCounter++;
    const instanceId = `wa${instanceCounter}`;

    const button = document.createElement('button');
    button.className = 'instance-button';
    button.setAttribute('data-instance', instanceId);
    button.textContent = `WhatsApp ${instanceCounter}`;
    button.onclick = () => showInstance(instanceId);
    instancesList.appendChild(button);

    const webview = document.createElement('webview');
    webview.id = instanceId;
    webview.className = 'webview-content';
    webview.src = 'https://web.whatsapp.com/';
    webview.partition = `persist:wa${instanceCounter}`;
    webview.useragent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36';
    webviewContainer.appendChild(webview);

    webview.addEventListener('page-title-updated', (event) => {
        const correspondingButton = document.querySelector(`[data-instance="${instanceId}"]`);
        if (event.title.includes('(')) {
            correspondingButton.classList.add('unread');
        } else {
            correspondingButton.classList.remove('unread');
            updateProfileInfo(webview, correspondingButton);
        }
    });

    webview.addEventListener('dom-ready', () => {
        setTimeout(() => updateProfileInfo(webview, button), 5000); // Espera 5 segundos
    });

    showInstance(instanceId);
}

addInstanceBtn.addEventListener('click', addInstance);

addInstance();